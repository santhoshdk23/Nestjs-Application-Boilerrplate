// src/app.module.ts

import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { UserModule } from './modules/user/user.module'; // Import UserModule
import { DatabaseModule } from './database/database.module'; // Import DatabaseModule
import { AppService } from './app.service';
import { AuthModule } from './modules/auth/auth.module';

@Module({
  imports: [UserModule, DatabaseModule,AuthModule], // Include both modules here
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
