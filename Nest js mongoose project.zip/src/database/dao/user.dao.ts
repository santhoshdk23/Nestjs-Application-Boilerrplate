// src/modules/user/user.dao.ts

import { Model } from 'mongoose';
import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { User } from '../schema/user.schema';
import { CreateUserDto } from '../../modules/user/create-user.dto';
import { PaginationDto } from 'src/modules/user/pagination.dto';

@Injectable()
export class UserDao {
  constructor(@InjectModel(User.name) private readonly userModel: Model<User>) {}

  async createUser(createUserDto: CreateUserDto): Promise<User> {
    const createdUser = new this.userModel(createUserDto);
    return await createdUser.save();
  }

  async findAllUsers(): Promise<User[]> {
    return await this.userModel.find().exec();
  }

  async findOneByUsername(username: string): Promise<User | null> {
    return await this.userModel.findOne({ uname: username }).exec();
  }

  async findOneById(id: string): Promise<User | null> {
    try {
      return await this.userModel.findById(id).exec();
    } catch (error) {
      throw new NotFoundException(`User with ID ${id} not found`);
    }
  }

  async deleteUser(userId: string): Promise<any> {
    const result = await this.userModel.deleteOne({ _id: userId }).exec();
    
    if (result.deletedCount === 0) {
      throw new NotFoundException(`User with ID ${userId} not found`);
    }
  }


  async getAllUsers(pageId: number, pageLimit: number, name: string) {

    try {

        let query = this.userModel.find({});



        if (name) {

            query = query.regex('name', new RegExp(name, 'i'));

        }



        const users = await query

            .skip((pageId - 1) * pageLimit)

            .limit(pageLimit);

            const totalUsers = await this.userModel.countDocuments().exec();

 

    if (!users || users.length === 0) {
      throw new NotFoundException('No users found');
    }

    return {
      users,
      currentPage: pageId,
      usersPerPage: pageLimit,
      totalUsers,
    }

    } catch (error) {

        return "Cant find";

    }

}

  // You can add more methods for specific database operations as needed.
}
