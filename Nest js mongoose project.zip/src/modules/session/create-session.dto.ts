// src/database/models/dto/create-session.dto.ts

export class CreateSessionDto {
    uid: string;
    rid: number;
    rname: string;
    start_ts: number;
    end_ts: number;
  }
  